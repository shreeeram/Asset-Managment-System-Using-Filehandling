#include <stdio.h>
#include<stdlib.h>
#include<ctype.h>
#include "include/main_asset.h"

int main(){


    int op=0;
while(1){

    printf("enter option");
    scanf("%d",&op);

switch(op){
    case 1:
   menu_asset();
   break;
    case 2:
  menu_employee();
   break;
   case 3:
   //asset_request();
   break;
}

}
    return 0;
}