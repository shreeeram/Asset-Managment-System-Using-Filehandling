
struct employee_data{

int employee_id;
char first_name[50];
char last_name[50];
char designation[50];
char joining_date[50];
char location[50];

};


struct employee{
struct employee_data  emp;
struct employee *next;

};

int employee_count;
int employee_count_list;
int fetched_file_employee;
FILE* fp_write_emp;
FILE *fp_read_emp;

int is_present;
void menu_employee();
int add_node_employee();
void add_employee();
int delete_employee(int);
void printlist_employee();
int update_employee(int);
int search_employee(int);

void savechanges_employee();
void BuildemployeeList();
void empty_employee();

