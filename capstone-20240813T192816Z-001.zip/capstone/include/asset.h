
struct asset_data{

int asset_id;
char asset_name[50];
char Purchase_date[50];
char EOL[50];
int isActive;
int tagging_status;
char type;
};


struct asset{
struct asset_data  data;
struct asset *next;

};




int asset_count;
int asset_count_list;
int fetched_file;
FILE* fp_write;
FILE *fp_read;
void menu_asset();
int add_node();
void add_asset();
int delete_asset(int);
void printlist();
int update_asset(int);
int search_asset(int);

void savechanges();
void BuildAssetList();
void empty_asset();

int isLeapYear(int);
char* calculateDateAfterFourYears(const char*);
