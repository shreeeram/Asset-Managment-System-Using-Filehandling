

//void assetrequest(void);