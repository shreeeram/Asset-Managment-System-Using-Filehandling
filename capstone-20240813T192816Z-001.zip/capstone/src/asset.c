#include <stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>
#include <time.h>

#include "../include/asset.h"
const char asset_type[]={'L','V','D'}; //L:LAPTOP, V:VOIP , D:DESKTOP
struct asset_data a_data;

struct asset *a1=NULL;


void empty_asset(){



// Delete linkedlist from beginning
struct asset *x;
x=a1;
a1= a1->next;
free(x);




}
int assetcount(){
int l=0;
fp_read=fopen("Asset.csv","r");
char ch='\0';
while((ch=fgetc(fp_read)) !=EOF){
    if(ch == '\n')
{
    l++;
}
}
  asset_count=l;
  return asset_count;
}

int assetcount_list(){
int l1=0;
struct asset *p=a1;
 while(p!=NULL){
l1++;
 asset_count_list=p->data.asset_id;
 
    p=p->next;
   
 }
 //printf("%d \n",asset_count_list);
//
  
  return asset_count_list;
}
void printlist(){
 struct asset *p=a1;
 while(p!=NULL){
printf("%d : %s\n",p->data.asset_id,p->data.asset_name);
    p=p->next;
 }
 printf("\n\n");
}



void BuildAssetList(){

//int a=assetcount();

/*int id_asset=0;
char name[100]="";
char pr[100]="";
char eol[100]="";
int ac=0;
char type='\0';*/
fp_read = fopen("Asset.csv","r") ; 

while(fscanf(fp_read,"%d,%[^,],%[^,],%[^,],%d,%d,%c",&a_data.asset_id,
	   a_data.asset_name,a_data.Purchase_date,a_data.EOL,&a_data.tagging_status,&a_data.isActive,&a_data.type)==7){


int is_present=0;

//printf("ppp=%d, %s, %s, %s, %d, %c\n",a_data.asset_id,a_data.asset_name,a_data.Purchase_date,a_data.EOL,a_data.isActive,a_data.type);


 struct asset *p=a1;
 while(p!=NULL){
if(p->data.asset_id==a_data.asset_id){

is_present=1;
break;
}
    p=p->next;
 }

if(is_present==0){
       add_node();
}
fetched_file=1;

}

}
void savechanges(){

fp_write = fopen("Asset.csv", "w");


 struct asset *p=a1;
 if (!fp_write) {
		
	printf("Can't open file\n");
		
	}

    
 while(p!=NULL){
fprintf(fp_write,"%d,%s,%s,%s,%d,%d,%c\n",p->data.asset_id,
	   p->data.asset_name, p->data.Purchase_date,p->data.EOL,p->data.tagging_status,p->data.isActive,p->data.type);


       p=p->next;
 
 
 }
 //empty_asset();
 
 



	



printf("\nNew Account added to record\n");




fclose(fp_write);




}



void menu_asset(){
fetched_file=0;
while(1){
printf(" 1.Press 1 to add asset\n2.Update Asset\n3.Search Asset\n4.Delete Asset\n5.Save Changes\n6.Print all Assets\n7.Exit\n->");
int op;
int id;
scanf("%d",&op);

switch(op){
case 1:


//printf("fetched: %d",fetched_file);
if(fetched_file!=1){
BuildAssetList();

}
assetcount_list();
printf("---- ALL ASSETS LOADED! ----");
add_asset();
printf("\n------\n");
printlist();
printf("\n------\n");
break;

case 2:
printf("--- Update Asset ---");
printf("Enter Asset Id:");
scanf("%d",&id);
update_asset(id);
printf("\n------\n");
printlist();
printf("\n------\n");
break;

case 3:
printf("--- Search Asset ---");
printf("Enter Asset Id:");
scanf("%d",&id);
search_asset(id);
printf("\n------\n");
printlist();
printf("\n------\n");
break;

case 4:
printf("--- Remove Asset ---");
printf("Enter Asset Id:");
scanf("%d",&id);
delete_asset(id);
printf("\n------\n");
printlist();
printf("\n------\n");
break;

 case 5:
savechanges();
break;

case 6:
printlist();
break;

case 7:
exit(0);
break;






}
}


}

int search_asset(int num){
struct asset *p=a1;

 while(p!=NULL){
if(p->data.asset_id == num){
   printf("\n--------------------------\n");
   printf("\n %d Asset Found\n",num);
   printf("Id: %d\n", p->data.asset_id);
   printf("Asset Name: %s\n", p->data.asset_name);
   printf("Purchase Date: %s\n", p->data.Purchase_date);
    printf("Tagging Status: %d\n" ,p->data.tagging_status);
   printf("Is active: %d\n" ,p->data.isActive);
   printf("Type: %c\n", p->data.type);
return 1;
  
}
    p=p->next;
 }

return 0;
 
}

int delete_asset(int num){
struct asset *p=a1;
struct asset *prev = NULL;
if(a1==NULL){
printf("\nNo Asset Found!\n");
return 0;
}

else if (a1->next==NULL){
    a1=NULL;
    return 1;
}

else{
if(a1->data.asset_id==num){
a1=a1->next;
}else{
int l = 0;
      while (p->next != NULL && p->data.asset_id != num)
	{
      prev = p;
	  p = p->next;
	  l++;
      }
    if (l == 0)
	{
        a1 = a1->next;
	}
    if(p->data.asset_id==num){
     prev->next = p->next;
     return 1;
    }
}
      }

      return 0;
}


int update_asset(int num){






int day=0;
int month=0;
int year=0;
 printf("\n--- UPDATE ASSET ---\n");
 printf("Enter name:");
 scanf("%s",a_data.asset_name);

  
 printf("\n-- Enter Purchase date --\n");
 
 printf("Enter year (yyyy): ");
 
  do {
     scanf("%d",&year);
     if(year<1000){
    printf("\nWarning: Please Enter year in (YYYY) Format\n");
     }
    
 }while(year<1000);
    
   printf("Enter month (mm): ");
    
     do{
      scanf("%d",&month);
       if(month>12 || month<1){
    printf("\nWarning: Please Enter Valid Month:");
       } 
    
 }while(month>12 || month<1);



   printf("Enter day (dd): ");


   do{
     scanf("%d",&day);
      if(day>31 ||  day<1){
    printf("\nWarning: Please Enter Valid Day(1-\n");
   
 } 

   }while(day>31 ||  day<1);


 sprintf(a_data.Purchase_date,"%d/%d/%d",day,month,year);





 

 
a_data.asset_id=num;


//int got=0;
struct asset *p=a1;

if(a1==NULL){
printf("NO EMPLOYYEE FOUND!");
return 0;
}
else{
if(a1->data.asset_id==num){
a1->data=a_data;
a1->data.asset_id=num;
//got=1;
}else{
int l = 0;
      while (p->next!= NULL && p->data.asset_id != num)
	{
   
	  p = p->next;
	  l++;
      }

if(p->data.asset_id==num){
      
    p->data=a_data;
    p->data.asset_id=num;
     printf(" found");
     return 1;

}
else{

    printf("not found");
}

}




}
return 0;
}


int add_node(){
struct asset *p=a1;
struct asset *temp;
temp=(struct asset*)malloc(sizeof(struct asset));
temp->data=a_data;
temp->next=NULL;

if(a1==NULL){
a1=temp;
return 1;
}
else{

while(p->next!=NULL){
  
    p = p->next;
}
p->next=temp;
return 1;
}
return 0;
}



void add_asset(){
/*a_data.asset_id=1;
strcpy(a_data.asset_name,"Phone");
strcpy(a_data.Purchase_date,"15/05/2023");
strcpy(a_data.EOL,"15/05/2023");
a_data.isActive=1;
a_data.type='P';   
       */




printf("\n--- ADD ASSET ---\n");
 printf("Enter name:");
 scanf("%s",a_data.asset_name);

  
 printf("\n--  Purchase date --\n");
   time_t currentTime = time(NULL);  // Get current time
    struct tm* localTime = localtime(&currentTime);  // Convert to local time
    
   
    strftime(a_data.Purchase_date, sizeof(a_data.Purchase_date), "%d/%m/%Y", localTime); 
 




  printf("\n--  EOL --\n");
 

 
 char *tmp_date=calculateDateAfterFourYears(a_data.Purchase_date);
 
 strcpy(a_data.EOL,tmp_date);
 
printf("\nEnter status(Tagged:1/Free:0):");
scanf("%d",&a_data.tagging_status);


printf("\nIs Active (Active:1/not active:0):");
scanf("%d",&a_data.isActive);
   printf("\nEnter asset type");
do{
 scanf(" %c",&a_data.type);
 a_data.type=toupper(a_data.type);

 if(a_data.type!=asset_type[0] && a_data.type!=asset_type[1]  && a_data.type!=asset_type[2]){
printf("Enter valid Asset type(L:LAPTOP | V:VOIP | D:DESKTOP):");
 }

}while(a_data.type!=asset_type[0] && a_data.type!=asset_type[1]  && a_data.type!=asset_type[2]);


 

a_data.asset_id=asset_count_list+1;



add_node();





/*

char asset_name[50];
char Purchase_date[50];
char EOL[50];
int isActive;

*/

//printf("%d %s %c",a1.data.asset_id,a1.data.asset_name,a1.data.type);

//addnode(&head,a_data);


 
 
 
 }   //



int isLeapYear(int year) {
    if ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0)
        return 1;  // Leap year
    else
        return 0;  // Not a leap year
}

// Function to calculate the date after adding 4 years, 0 months, and 0 days
char* calculateDateAfterFourYears(const char* inputDate) {
    int year, month, day;
    char* token;
    char* result = (char*)malloc(11 * sizeof(char));  // Allocate memory for the result string
    
    // Split the input date string into year, month, and day
    char* inputCopy = strdup(inputDate);
    token = strtok(inputCopy, "/");
    day = atoi(token);
   
    token = strtok(NULL, "/");
    month = atoi(token);
    token = strtok(NULL, "/");
     year = atoi(token);
    
    
    // Add 4 years to the current year
    year += 4;
    
    // Check if the current year is a leap year and adjust February 29th if necessary
    if (isLeapYear(year) && month == 2 && day == 29) {
        day = 28;  // Set day to 28 for leap years if it was originally 29
    }
    
    // Format the calculated date into the result string
    snprintf(result, 11, "%02d/%02d/%d", day, month, year);
    
    free(inputCopy);  // Free the memory allocated for inputCopy
    
    printf("result %s",result);
    return result;
}
