#include <stdio.h>
#include<stdlib.h>

void tagging(){

printf("\nassetTaging.c working!\n");


    
}