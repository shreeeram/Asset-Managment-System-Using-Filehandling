#include <stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>

#include "../include/employee.h"
const char employee_type[]={'L','V','D'}; //L:LAPTOP, V:VOIP , D:DESKTOP
struct employee_data a_data_emp;

struct employee *a2=NULL;


void empty_employee(){



// Delete linkedlist from beginning
struct employee *x;
x=a2;
a2= a2->next;
free(x);

 


}
int employeecount(){
int l=0;
fp_read_emp=fopen("Employee.csv","r");
char ch='\0';
while((ch=fgetc(fp_read_emp)) !=EOF){
    if(ch == '\n')
{
    l++;
}
}
  employee_count=l;
  return employee_count;
}

int employeecount_list(){
int l1=0;
struct employee *p=a2;
 while(p!=NULL){
l1++;
 employee_count_list=p->emp.employee_id;
 
    p=p->next;
   
 }
 //printf("%d \n",employee_count_list);
//
  
  return employee_count_list;
}
void printlist_employee(){
 struct employee *p=a2;
 while(p!=NULL){
printf("%d : %s\n",p->emp.employee_id,p->emp.first_name);
    p=p->next;
 }
 printf("\n\n");
}



void BuildemployeeList(){

//int a=employeecount();

/*int id_employee=0;
char name[100]="";
char pr[100]="";
char eol[100]="";
int ac=0;
char type='\0';*/
fp_read_emp = fopen("Employee.csv","r") ; 

//while(fscanf(fp_read_emp,"%d,%[^,],%[^,],%[^,],%[^,],%[^ ]",&a_data_emp.employee_id,a_data_emp.first_name,a_data_emp.last_name,a_data_emp.designation,a_data_emp.joining_date,a_data_emp.location)==6){

while(fscanf(fp_read_emp,"%d,%[^,],%[^,],%[^,],%[^,],%s",&a_data_emp.employee_id,a_data_emp.first_name,a_data_emp.last_name,a_data_emp.designation,a_data_emp.joining_date,a_data_emp.location)==6){



is_present=0;


printf("%d %s\n",a_data_emp.employee_id,a_data_emp.first_name);

 struct employee *p=a2;
 while(p!=NULL){
if(p->emp.employee_id==a_data_emp.employee_id){

is_present=1;
break;
}
    p=p->next;
 }

if(is_present==0){
       add_node_employee();
}
fetched_file_employee=1;

}

}
void savechanges_employee(){

fp_write_emp = fopen("Employee.csv", "w");


 struct employee *p2=a2;
 if (!fp_write_emp) {
		
	printf("Can't open file\n");
		
	}

    
 while(p2!=NULL){
    
fprintf(fp_write_emp,"%d,%s,%s,%s,%s,%s\n",p2->emp.employee_id,p2->emp.first_name,p2->emp.last_name,p2->emp.designation,p2->emp.joining_date,p2->emp.location);


       p2=p2->next;
 
 
 }
 //empty_employee();
 
 



	



printf("\nNew Account added to record\n");




fclose(fp_write_emp);




}



void menu_employee(){
fetched_file_employee=0;
while(1){
printf("1.Press 1 to add employee\n2.Update employee\n3.Search employee\n4.Delete employee\n5.Save Changes\n6.Print all employees\n7.Exit\n->");
int op;
int id;
scanf("%d",&op);

switch(op){
case 1:


printf("fetched: %d",fetched_file_employee);
if(fetched_file_employee!=1){
BuildemployeeList();

}
employeecount_list();
printf("---- ALL employeeS LOADED! ----");
add_employee();
printf("\n------\n");
printlist_employee();
printf("\n------\n");
break;

case 2:
printf("--- Update employee ---");
printf("Enter employee Id:");
scanf("%d",&id);
update_employee(id);
printf("\n------\n");
printlist_employee();
printf("\n------\n");
break;

case 3:
printf("--- Search employee ---");
printf("Enter employee Id:");
scanf("%d",&id);
search_employee(id);
printf("\n------\n");
printlist_employee();
printf("\n------\n");
break;

case 4:
printf("--- Remove employee ---");
printf("Enter employee Id:");
scanf("%d",&id);
delete_employee(id);
printf("\n------\n");
printlist_employee();
printf("\n------\n");
break;

 case 5:
savechanges_employee();
break;

case 6:
printlist_employee();
break;

case 7:
exit(0);
break;






}
}


}

int search_employee(int num){
struct employee *p=a2;

 while(p!=NULL){
if(p->emp.employee_id == num){
   printf("\n--------------------------\n");
 
   printf("employee ID: %d\n", p->emp.employee_id);
   printf("employee Name: %s\n", p->emp.first_name);
   printf("Purchase Date: %s\n", p->emp.last_name);
   printf("Is active: %s\n" ,p->emp.designation);
   printf("Type: %s\n", p->emp.joining_date);
   printf("Type: %s\n", p->emp.location);



return 1;
  
}
    p=p->next;
 }

return 0;
 
}

int delete_employee(int num){
struct employee *p=a2;
struct employee *prev = NULL;
if(a2==NULL){
printf("\nNo employee Found!\n");
return 0;
}

else if (a2->next==NULL){
    a2=NULL;
    return 1;
}

else{
if(a2->emp.employee_id==num){
a2=a2->next;
}else{
int l = 0;
      while (p->next != NULL && p->emp.employee_id != num)
	{
      prev = p;
	  p = p->next;
	  l++;
      }
    if (l == 0)
	{
        a2 = a2->next;
	}
    if(p->emp.employee_id==num){
     prev->next = p->next;
     return 1;
    }
}
      }

      return 0;
}


int update_employee(int num){

a_data_emp.employee_id=num;
int day=0;
int month=0;
int year=0;



 printf("\n--- ADD employee ---\n");
 printf("Enter First name:");
 scanf("%s",a_data_emp.first_name);

 printf("Enter Last name:");
  scanf("%s",a_data_emp.last_name);


 printf("Enter Designation:");
 scanf("%s",a_data_emp.designation);


 printf("Enter Joining Date:");

printf("\n-- Enter Purchase date --\n");
 
 printf("Enter year (yyyy): ");
 
  do {
   
     scanf("%d",&year);
     if(year<1000  || year==0){
    printf("\nWarning: Please Enter year in (YYYY) Format\n");
     }
    
 }while(year<1000 || year==0);
    
   printf("Enter month (mm): ");
    
     do{
      scanf("%d",&month);
       if(month>12 || month<1 ||  month==0){
    printf("\nWarning: Please Enter Valid Month:");
       } 
    
 }while(month>12 || month<1 || month==0);



   printf("Enter day (dd): ");


   do{
     scanf("%d",&day);
      if(day>31 ||  day<1 || day==0){
    printf("\nWarning: Please Enter Valid Day(1-\n");
   
 } 

   }while(day>31 ||  day<1 || day==07);

 sprintf(a_data_emp.joining_date,"%d/%d/%d",day,month,year);
 printf("Enter Location:");
 scanf("%s",a_data_emp.location);

  




 




//int got=0;
struct employee *p=a2;

if(a2==NULL){
printf("NO EMPLOYYEE FOUND!");
return 0;
}
else{
if(a2->emp.employee_id==num){
a2->emp=a_data_emp;
a2->emp.employee_id=num;
//got=1;
}else{
int l = 0;
      while (p->next!= NULL && p->emp.employee_id != num)
	{
   
	  p = p->next;
	  l++;
      }

if(p->emp.employee_id==num){
      
    p->emp=a_data_emp;
;
    p->emp.employee_id=num;
     printf(" found");
     return 1;

}
else{

    printf("not found");
}

}




}
return 0;
}


int add_node_employee(){
struct employee *p=a2;
struct employee *temp;
temp=(struct employee*)malloc(sizeof(struct employee));
temp->emp=a_data_emp;
temp->next=NULL;

if(a2==NULL){
a2=temp;
return 1;
}
else{

while(p->next!=NULL){
  
    p = p->next;
}
p->next=temp;
return 1;
}
return 0;
}



void add_employee(){
/*a_data_emp.employee_id=1;
strcpy(a_data_emp.employee_name,"Phone");
strcpy(a_data_emp.Purchase_date,"15/05/2023");
strcpy(a_data_emp.EOL,"15/05/2023");
a_data_emp.isActive=1;
a_data_emp.type='P';   
       */


int day=0;
int month=0;
int year=0;



 printf("\n--- ADD employee ---\n");
 printf("Enter First name:");
 scanf("%s",a_data_emp.first_name);

 printf("Enter Last name:");
  scanf("%s",a_data_emp.last_name);


 printf("Enter Designation:");
 scanf("%s",a_data_emp.designation);


 printf("Enter Joining Date:");

printf("\n-- Enter Purchase date --\n");
 
 printf("Enter year (yyyy): ");
 
  do {
   
     scanf("%d",&year);
     if(year<1000  || year==0){
    printf("\nWarning: Please Enter year in (YYYY) Format\n");
     }
    
 }while(year<1000 || year==0);
    
   printf("Enter month (mm): ");
    
     do{
      scanf("%d",&month);
       if(month>12 || month<1 ||  month==0){
    printf("\nWarning: Please Enter Valid Month:");
       } 
    
 }while(month>12 || month<1 || month==0);



   printf("Enter day (dd): ");


   do{
     scanf("%d",&day);
      if(day>31 ||  day<1 || day==0){
    printf("\nWarning: Please Enter Valid Day(1-\n");
   
 } 

   }while(day>31 ||  day<1 || day==07);

 sprintf(a_data_emp.joining_date,"%d/%d/%d",day,month,year);
 printf("Enter Location:");
 scanf("%s",a_data_emp.location);

  




 

a_data_emp.employee_id=employee_count_list+1;



add_node_employee();





/*

char employee_name[50];
char Purchase_date[50];
char EOL[50];
int isActive;

*/

//printf("%d %s %c",a2.data.employee_id,a2.data.employee_name,a2.data.type);

//addnode(&head,a_data_emp);


 
 
 
 }   //
